# Delights


(creation of all is still in progress)








The ultimate aim of the canteen management app is to automate the
existing traditional system which is manual, with the support of Android App
and full-featured Mobile applications, so that their valuable data can be
retained for a prolonged period of time with quick access and management.

The appropriate software and hardware are readily accessible and easy to use.
There is a huge line in the institution cafeteria throughout the break. From the
wait at the payment desk to the serving point, a ton of time is spent waiting for
the food, because of which, students and the faculty get late for their lectures.
All teachers and students do want to figure out a way to do that or get rid of
this waiting period.

One way to resolve the issue would be to have a software arrangement in
which, once the order has been put, it can be projected directly on the cafeteria
monitor.
This will prevent the time people spend at the payment desk as the
server needs time to fulfill the previous orders before taking a fresh receipt and
setting it up in the cafeteria.We could have the program to post orders in sucha manner that his / her order is processed ready for the particular period that
he/she prefers. The time wasted on waiting for change can also be diminished
by enabling online payment. The project's main objective on the Canteen
Automated App is to manage canteen, product, and sales information.It
manages all the details of canteen, product, orders and users. The project is
completely built at the administrative end and thus only admin is guaranteed
access.


